package packer;

/**
 *
 * @author Frank Eriguel - 91030193
 */
public class Depot {
    private String name;
    private Address address;

    public Depot(String name, Address address) {
        /**
         * Initializer
         */
        this.name = name;
        this.address = address;
    }
     //REMOVED ADDRESS.TOSTRING() AND REPLACED WITH NAME
    //This Enabled me to extract the depo name to depotest.java
    /**
     * getNAme
     * @return name
     */
    public String getName() {
        return name;
    }
    /**
     * getCoordinates
     * @return coordinates
     */
    public Coordinates getCoordinates() {
        return this.address.getCoordinates();
    }
    /**
     * toString
     * @return getName
     */
    public String toString() {
        return this.getName();
    }
    
}
