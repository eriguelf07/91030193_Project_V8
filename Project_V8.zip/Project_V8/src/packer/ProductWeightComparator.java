package packer;

import java.util.Comparator;

/**
 *
 * @author  Frank Eriguel - 91030193
 * 
 * This is used when we need to sort by product weight descending
 */
public class ProductWeightComparator implements Comparator<Product> {
    /**
     * compare
     * @param a
     * @param b
     * @return something
     */
    public int compare(Product a, Product b) {
        if (a.getWeight() < b.getWeight()) {return 1;}
        else if (a.getWeight() > b.getWeight()) {return -1;}
        else return a.getName().compareTo(b.getName());
    }
                
}
