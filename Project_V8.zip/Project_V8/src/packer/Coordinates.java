package packer;

/**
 *
 * @author Frank Eriguel - 91030193
 */

public class Coordinates {
    
    private final double x;
    private final double y;
    /**
     * Initializer
     * @param x coordinates
     * @param y coordinates
     */
    public Coordinates(double x, double y) {
        this.x = x;
        this.y = y;
    }
/**
 * getX
 * @return X coordinates
 */
    public double getX() {
        return x;
    }
/**
 * getY
 * @return Y coordinates
 */
    public double getY() {
        return y;
    }
    /**
     * euclideanDistanceTo
     * @return Distance string
     */
    public double euclideanDistanceTo(Coordinates other) {
        double xDiff = other.getX() - this.getX();
        double yDiff = other.getY() - this.getY();
        double dist = Math.pow((xDiff * xDiff + yDiff * yDiff),0.5);
        return dist;
    }
    /**
     * manhattanDistanceTo
     * @return DistanceManhattan string
     */
    public double manhattanDistanceTo(Coordinates other) {
        double xDiff = other.getX() - this.getX();
        double yDiff = other.getY() - this.getY();
        double dist = Math.abs(xDiff) + Math.abs(yDiff);
        return dist;
    }
    //TRIED GOING WITH GOEMETRICAL APPROACH: (X1(SQUARED) + Y1(SQUARED)) - (X2(SQUARED) + Y2(SQUARED)), XY2(SQUARED) - XY2(SQUARED) IS THE DISTANCE.
    //DIDNT WORK..
    //HOW THE HELL DOES THIS CODE WORK
    /**
     * companyDistanceTo
     * @return Coordinates Distance
     */
    public double companyDistanceTo(Coordinates other) {
        double xDiff1 = other.getX() - this.getX();
        double yDiff1 = other.getY() - this.getY();
        double dist1 = Math.pow((xDiff1 * xDiff1 + yDiff1 * yDiff1),0.5);
        double xDiff2 = other.getX() - this.getX();
        double yDiff2 = other.getY() - this.getY();
        double dist2 = Math.abs(xDiff2) + Math.abs(yDiff2);
        //ASSUMED THAT NUMBERS WILL ROUND UP TO ONE(FOR THE SECOND TEST), I JUST ADDED A PLUS ONE
        return (dist1 + dist2)/2 + 1;
    }

}
